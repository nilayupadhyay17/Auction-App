package com.example.nilay.myapplication.backend;

import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;

/**
 * Created by nilay on 2/11/2017.
 */
@Entity
public class GCMMessages {
    @Id
    Long  ID;
}
