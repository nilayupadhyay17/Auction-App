package app.com.upadhyay.nilay.myapplication;

/**
 * Created by nilay on 2/2/2017.
 */

public class QuickstartPreferences  {
    public static final String SENT_TOKEN_TO_SERVER = "sentTokenToServer";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
}
