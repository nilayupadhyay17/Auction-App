package app.com.upadhyay.nilay.myapplication;

import com.google.android.gms.iid.InstanceIDListenerService;

/**
 * Created by nilay on 2/1/2017.
 */

public class MyInstanceIDListenerService extends InstanceIDListenerService {
}
